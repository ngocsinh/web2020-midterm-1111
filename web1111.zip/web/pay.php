<?php
include 'header.php';
?>


            <!-- body -->
             <!-- body -->
             <div id="body">
                 <br>
                <!-- introduce-nav -->
                <div id="introduce-nav">
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/xe.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href=" delivery.php"><h5 style="color:black">Giao hàng toàn quốc</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/money.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href=" pay.php"><h5 style="color:black">Thanh toán khi nhận hàng</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/tra.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a  href=" return.php"><h5 style="color:black">Đổi trả trong vòng 7 ngày</h5></a>
                        </div>
                    </div>
                </div>

                <!-- Nội dung -->
                <div>
                    <div>
                       <br>
                        <h4>HÌNH THỨC THANH TOÁN</h4>
                        <br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>1. Thanh toán tiền mặt khi nhận hàng (C.O.D):&nbsp;</strong><br>
                            - Tên gọi COD là viết tắt của Cash On Delivery, nghĩa là thanh toán khi nhận hàng. Với phương thức thanh toán này, quý khách sẽ trả tiền mặt cho nhân viên giao hàng ngay khi nhận được đơn hàng của mình.
                            <br><br>
                            - Ngay sau khi nhận được đơn đặt hàng qua facebook, website, email... CSKH Xinh sẽ xác nhận với Quý khách qua điện thoại, tiến hành thực hiện đơn hàng và giao hàng.
                            <br><br>
                            -Chấp nhận hình thức thanh toán khi nhận hàng (COD) cho tất cả các đơn hàng trên toàn quốc.
                            <br><br>
                            - Ngoài ra quý khách có thể thanh toán tiền mặt trực tiếp khi mua hàng tại cửa hàng.

                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>2. Chuyển khoản ngân hàng&nbsp;</strong><br>
                            - Quý khách hàng có thể Chuyển khoản trực tiếp vào tài khoản ngân hàng của của shop tại các ngân hàng với nội dung:
                            <br><br>
                            - Tên + SĐT đặt hàng + sản phẩm
                            <br><br>
                            - CSKH sẽ xác nhận với Quý khách qua điện thoại, tiến hành thực hiện đơn hàng và giao hàng.
                            <br><br>
                            - Thông tin chi tiết các Số Tài Khoản Ngân Hàng : 
                            <br><br>
                            - Ngân Hàng Vietcombank
                            <br><br>
                            - STK: 0071005378474
                            <br><br>
                            - Chủ tài khoản: Nguyễn Văn A
                            <br><br>
                            ---------------------------
                            <br><br>
                            - AGRIBANK HỒ CHÍ MINH
                            <br><br>
                            - STK:1606205599654
                            <br><br>
                            - Chủ tài khoản: Nguyễn Văn A
                            <br><br>
                            - Ghi chú: Sau khi chuyển khoản, quý khách vui lòng thông báo cho chúng tôi việc chuyển tiền và số tài khoản của quý khách (bằng điện thoại, email, facebook …) để thuận tiện trong việc kiểm tra.
                            <br>  <br>                
                        </span>
                        <br><br>
                        <hr><hr>

                    </div>
                </div>

            </div>  
              <!-- footer -->
            <div >
                <img id="footer" src=" image/footer.jpg" alt="">
                
            </div>
  
        </div>
    </body>
</html>