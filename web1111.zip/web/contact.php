<?php
include 'header.php';
?>

                
                <div >
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.6511050549!2d106.68001951472597!3d10.76134939233174!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752f1b888ab357%3A0xc469f6e800231314!2zMjgwIEFuIEQuIFbGsMahbmcsIFBoxrDhu51uZyA0LCBRdeG6rW4gNSwgVGjDoG5oIHBo4buRIEjhu5MgQ2jDrSBNaW5oLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1600412484926!5m2!1svi!2s" width="1000" height="500px" frameborder="0" style="border:0; margin-top: 40px; margin-left: 50px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
               
                  <div style="border-radius: 10px; margin-top: 15px; margin-left: 90px; margin-bottom: 25px; height:100px; ">
                    <div class="contact">
                      <span > <b >HÀ NỘI</b><br>
                        195 Cầu Giấy, Dịch Vọng, Hà Nội 
                       <br> 024 6260 1370 - <a style="font-weight:bolder" target="_blank" href="https://goo.gl/maps/83DA9uSJq55GSYct5">Xem bản đồ</a>
                      </span>
                    </div>
                    <div class="contact">
                      <span><b>TP.HCM</b> <br>
                        280 An Dương Vương,quận 5, Tp.HCM 
                        <br> 024 6260 1370 - <a style="font-weight:bolder" target="_blank" href="https://goo.gl/maps/7sadGeip4yr4Pc3S9">Xem bản đồ</a>
                      </span>
                    </div>
                    <div class="contact">
                      <span><b>ĐÀ NẴNG</b><br>
                        372 Hùng Vương, Đà Nẵng
                        <br>0122 4464 030 - <a style="font-weight:bolder" target="_blank" href="https://goo.gl/maps/Y2ZVs4FhmsomicEW9">Xem bản đồ</a>
                      </span>
                    </div>
                </div>
                 <!-- footer -->
            <div >
              <img id="footer" src="image/footer.jpg" alt="">
              
          </div>
        </div>
    </body>
</html>