<?php
session_start();
include_once("call_api.php");


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hóa đơn</title>
    <link rel="stylesheet" href="../css.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src=" https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.js"></script>
</head>
<body>
<?php if( isset($_SESSION['admin'])) : ?>
    
        
            <!-- body -->
             <!-- body -->
             <div id="body" style="padding-left:150px;text-align:center">
             <a style="float:left" href="logoutAdmin.php"><button class='btn-add btn btn-danger' >LogOut</button></a>
             
             <a style="float:left;margin-left:100px" href="edit.php"><button class='btn-add btn btn-danger' >Danh sách sản phẩm</button></a>
                    <br><br><br>
                    <h2 style="margin-left:140px;color:red">Danh sách đơn hàng</h2>
                    <div style="width:1152px; height:50px; margin-left:41px; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:150px; height:50px;display:inline-block;float:left">Mã đơn hàng</div>

                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:200px; height:50px;display:inline-block;float:left">ID User</div>

                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:200px; height:50px;display:inline-block;float:left">Ngày đặt hàng</div>

                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:251px; height:50px;display:inline-block;float:left">Địa điểm giao hàng</div>
                        <div style="color:#0fce0f;font-weight:bold;padding-top:10px;text-align:center;width:251px; height:50px;display:inline-block;float:left">Tổng tiền</div>
                        

                    </div>
                    <div style=" overflow-y:scroll;width:1165px; max-height:500px; min-height:499px; margin-left:41px; margin-right:auto; margin-bottom:200px">
                          
                        
                    <?php 
          
                  
          $get_data = get("http://35.219.60.232/api.php/hoadons");
          $data= json_decode($get_data, true);
          foreach($data as $i){
                echo ' 
                
                    
                    <div style="width:1152px;min-height:90px; margin-left:auto; margin-right:auto;margin-bottom:10px; background-color: rgb(231, 231, 231);">
                        <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:150px; min-height:90px;display:inline-block;float:left">'.$i['idbill'].'</div>

                        <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:200px; min-height:90px;display:inline-block;float:left">'.$i['iduser'].'</div>

                        <div style="border-right:1px dashed #7b95b6;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;padding-bottom:20px;text-align:center;width:200px; min-height:90px;display:inline-block;float:left">'.$i['ngaydathang'].'</div>

                        <div style="border-right:1px dashed #7b95b6;font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:90px;display:inline-block;float:left">'.$i['noigiao'].' vnđ</div>
                        
                        <div style="border-right:1px dashed #7b95b6;font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:251px;padding-bottom:20px; min-height:90px;display:inline-block;float:left">'.$i['tongtien'].' vnđ</div>

                        <div style="font-weight:bold;color:red;border-top:2px solid #7b95b6;background-color: rgb(231, 231, 231);padding-top:20px;text-align:center;width:100px;padding-bottom:20px; min-height:90px;display:inline-block;float:left"><a href="#">Chi tiết</a></div>
                    </div>
                    

                ';
                            
                }
                ?>
                        
                        
                           

                    </div>

            <?php else: ?>
                    <div style="height:700px;padding-top:200px;text-align:center;">
                        <div  style="height:100px;border: 5px dashed black; border-radius: 100px;text-align:center;padding-top:18px">
                            <h1 style="color:red;">Vui lòng <a id="login-order" style=" text-decoration: none;" href="index.php">đăng nhập</a> trước khi sử dụng tính năng này</h1>
                        </div>
                        
                    </div>
                
            <?php endif; ?> 
</body>
</html>