<?php

include 'header.php';


$erorrs = [];
if(isset($_POST['name'])){
    $name = $_POST['name'];
    $password = $_POST['pass'];
 
    if(!$erorrs){
        $_SESSION['profile'] = $_POST;
        header('location: index.php');
    }
    
}

// $get_data1 = post("http://35.219.60.232/api.php/users?action=login",$postData);
// echo $get_data1;






?>

<?php if( isset($_SESSION['profile'])) : ?>
            <div style="height:700px;padding-top:200px;text-align:center;">
                <div  style="height:100px;border: 5px dashed black; border-radius: 100px;text-align:center;padding-top:18px">
                    <h1 style="color:red;">Bạn không thể sử dụng tính năng này</h1>
                </div>
                
            </div>
  <?php else: ?>
            
                
  
            <!-- body -->
             <!-- body -->
             <div id="body" >
                 <div  style="text-align: center; padding-top: 80px; height: 670px; width: 1100px;" class="bg-dark">
                     <div id="login">

                    

                        <form id="form-login" action="" method="POST">
                            <h2 style="margin-top: 50px;">ĐĂNG NHẬP</h2>
                            <div id="enter">
                                <img src=" image/user.PNG">
                                <input id="login-user" type="text" placeholder="Username" name='name'>
                            </div>
                            <div id="enter">
                                <img src=" image/pass.PNG">
                                <input id="login-pass" type="password" name="pass" placeholder="Password" >
                            </div>
                                    
                            <button type='submit' id="btn-login">Đăng nhập</button><br>

                        </form>
                        <div  style="width: 320px;height: 30px;margin-left: auto;margin-right: auto; margin-top: 10px; ">
                          <h7 id="error" style="font-weight: bold;color: red;"></h7>
                        </div>
                        
                    </div>
                    <h6 style="color:white;">Chưa có tài khoản? <a href=" signup.php">Đăng ký ngay</a></h6>
                     
                </div>    
              </div>
<?php endif; ?>
              <!-- footer -->
            <div >
              
                <img id="footer" src=" image/footer.jpg" alt="">
              </div>
  
        
      </div>
      <script>

        function check(ele){
                    if(ele.val()==""){
                      return true;
                    }
                    return false;
                  }

        $(function(){
          
          $("#btn-login").click(function(){
            var user = $("#login-user");
            var pass = $("#login-pass");

            if(check(user) || check(pass)){
              $("#error").html("Vui lòng nhập đầy đủ thông tin");
              return;
            }

            if( user.val().length<6 || pass.val().length<6 ){
              $("#error").html("Username/password tối thiểu 6 ký tự");
              return;
            }
            if( user.val().length>20 || pass.val().length>20 ){
              $("#error").html("Username/password không quá 20 ký tự");
              return;
            }
          });
        });

        $(function () {

                $("#form-login").validate({
                    rules: {
                        name: { required: true,minlength:6,maxlength:20 },
                        pass: {required: true ,minlength:6,maxlength:20 },
  
                    },
                    messages: {
                      name: { required: "",minlength:"",maxlength:"" },
                        pass: {required: "" ,minlength:"",maxlength:"" },
                      
                    }
                });
            });

      </script>
  </body>
</html>