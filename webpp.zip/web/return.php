<?php
include 'header.php';
?>

            <!-- body -->
             <!-- body -->
             <div id="body">
                 <br>
                <!-- introduce-nav -->
                <div id="introduce-nav">
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/xe.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href=" delivery.php"><h5 style="color:black">Giao hàng toàn quốc</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/money.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a href=" pay.php"><h5 style="color:black">Thanh toán khi nhận hàng</h5></a>
                        </div>
                    </div>
                    <div class="introduce-nav-box">
                        <div class="introduce-nav-image">
                            <img src=" image/tra.png" alt="">            
                        </div>
                        <div class="introduce-nav-name">
                            <a  href=" return.php"><h5 style="color:black">Đổi trả trong vòng 7 ngày</h5></a>
                        </div>
                    </div>
                </div>

                <!-- Nội dung -->
                <div>
                    <div>
                       <br>
                        <h4>QUY ĐỊNH ĐỔI, TRẢ HÀNG HAY HOÀN TIỀN</h4>
                        <br><br>
                        <h5>Cam kết sẽ thực hiện <p style="color: red; display: inline;">ĐỔI - TRẢ - HOÀN TIỀN</p> cho khách hàng trong những trường hợp sau:</h5>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>1.  Sản phẩm giao không đúng đơn đặt hàng&nbsp;</strong><br><br>
                            - Bạn nghĩ rằng sản phẩm giao cho bạn không đúng với đơn đặt hàng? Hãy liên hệ với chúng tôi càng sớm càng tốt, hệ thống của chúng tôi sẽ kiểm tra nếu hàng của bạn bị gửi nhầm. Trong trường hợp đó, chúng tôi sẽ thay thế đúng mặt hàng bạn yêu cầu (khi có hàng) hoàn toàn miễn phí.
                        
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>2. Sản phẩm mua rồi nhưng không ưng ý&nbsp;</strong><br><br>
                            - Khách hàng có thể trả hàng khi không vừa ý trong vòng 7 ngày kể từ ngày nhận hàng, shop sẽ đổi sản phẩm khác theo yêu cầu hoặc hoàn tiền cho khách hàng.
                            <br><br>
                            - Sản phẩm muốn đổi hoặc trả yêu cầu phải là sản phẩm không có dấu hiệu đã qua sử dụng và còn nguyên tem, mác, nguyên đai kiện ban đầu. 
                            <br><br>
                            - Sản phẩm muốn đổi phải có giá trị tương đương hoặc cao hơn sản phẩm đã mua. Shop sẽ trừ trực tiếp số tiền khách đã thanh toán vào đơn hàng mới, khách chỉ phải thanh toán phần chên lệch giá giữa hai sản phẩm.
                        
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>3. Sản phẩm mua bị lỗi&nbsp;</strong><br><br>
                            - Sau khi thanh toán quý khách hàng kiểm tra thấy sản phẩm bị lỗi do nhà sản xuất, chụp hình gửi qua cho shop xác nhận. Trong trường hợp sản phẩm bị hư hại trong quá trình vận chuyển, quý khách vui lòng từ chối và gửi lại sản phẩm. Đồng thời thông báo cho Trung tâm hỗ trợ khách hàng 023 456 7890 , Shop sẽ gửi cho quý khách mặt hàng thay thế.
                        </span>
                        <br><br>
                        <span style="font-size: 12pt; text-align: left;" data-mce-style="font-size: 12pt;">
                            <strong>4. Điều kiện đổi trả hàng&nbsp;</strong><br><br>
                            - Điều kiện về thời gian đổi trả: trong vòng 7 ngày kể từ khi nhận được hàng.
                            <br><br>
                            - Điều kiện về sản phẩm:
                            <br><br>
                            - Hàng hóa còn đầy đủ các bộ phận, không có dấu hiệu sử dụng đã qua sử dụng, giặt ủi. Còn nguyên tem Mạc của nhà sản xuất.
                            <br><br>
                            - Khách hàng vui lòng chịu chi phí vận chuyển cho việc đổi, trả hàng.
                            <br><br>
                            - Trường hợp không đủ các điều kiện trên thì quyền quyết định đổi, trả hàng thuộc về của hàng.
                        </span>
                        <br><br>
                        <hr><hr>

                    </div>
                </div>

            </div>  
              <!-- footer -->
            <div >
                <img id="footer" src=" image/footer.jpg" alt="">
                
            </div>
  
        </div>
    </body>
</html>